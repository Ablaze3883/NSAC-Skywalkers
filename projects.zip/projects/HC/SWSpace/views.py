from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    return render (request,'index.html')

def index(request):
    return render (request,'index.html')
def xray_uv_chandra(request):
    return render(request,'xray_uv_chandra.html')

def xray_uv_galex(request):
    return render(request ,'xray_uv_galex.html')

def xray_uv_spitzer(request):
    return render(request,'xray_uv_spitzer.html')

def spgi(request):
    return render(request,'specctral_graph_iue.html')

def spci(request):
    return render(request,'specctral_graph_chandra.html')

def oih(request):
    return render (request,'optical_image_hla.html')

def oic(request):
    return render (request,'optical_image_chandra.html')

def ois(request):
    return render(request,'optical_image_swift.html')