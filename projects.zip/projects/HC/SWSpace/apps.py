from django.apps import AppConfig


class SwspaceConfig(AppConfig):
    name = 'SWSpace'
