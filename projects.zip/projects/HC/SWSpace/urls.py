from django.urls import path

from .import views

urlpatterns = [
      path('',views.home,name='home'),
      path('index',views.index,name='index'),
      path('xray_uv_chandra',views.xray_uv_chandra,name='xray_uv_chandra'),
      path('xray_uv_galex',views.xray_uv_galex,name='xray_uv_galex'),
      path('xray_uv_spitzer',views.xray_uv_spitzer,name='xray_uv_spitzer'),
      path('spgi',views.spgi,name='spgi'),
      path('spci',views.spci,name='spci'),
      path('oih',views.oih,name='oih'),
      path('oic',views.oic,name='oic'),
      path('ois',views.ois,name='ois'),
     ]